package business

import (
	"context"
	"testing"
)

func TestReviewDisabledGroupMustNotReportParticipating(t *testing.T) {
	store := openPolicyStore(t)
	ctx := context.Background()
	if _, err := store.db.ExecContext(ctx, `INSERT INTO local_groups(name,remote_id,updated_at) VALUES('codex','7','now'); INSERT INTO accounts(id,name,multiplier,schedulable,metadata_json,updated_at) VALUES('41','account','1',1,'{}','now'); INSERT INTO account_groups(account_id,group_name,group_id) VALUES('41','codex','7')`); err != nil {
		t.Fatal(err)
	}
	row, err := store.UpdateGroupPolicy(ctx, "7", map[string]any{
		"enabled": false, "strategy": nil, "min_pool_size": 1, "weight_budget": 400,
		"balanced_price_ratio": 0.5, "breaker_enabled": true, "recovery_enabled": true,
		"weights_enabled": true, "scaling_enabled": false, "probe_enabled": true,
		"probe_interval_seconds": 300, "probe_model": nil,
	}, "review")
	if err != nil {
		t.Fatal(err)
	}
	if row.ParticipationStatus == "participating" || row.Status == "healthy" {
		t.Fatalf("disabled group still presented as managed: participation=%q status=%q override=%+v", row.ParticipationStatus, row.Status, row.Override)
	}
}

func TestReviewNumericGroupNameMustNotMatchExcludedID(t *testing.T) {
	store := openPolicyStore(t)
	ctx := context.Background()
	if _, err := store.db.ExecContext(ctx, `INSERT INTO local_groups(name,remote_id,updated_at) VALUES('codex','7','now'),('7','8','now')`); err != nil {
		t.Fatal(err)
	}
	if _, err := store.UpdatePolicy(ctx, map[string]any{"excluded_group_ids": []any{"7"}}, "review"); err != nil {
		t.Fatal(err)
	}
	rows, err := store.Groups(ctx)
	if err != nil {
		t.Fatal(err)
	}
	for _, row := range rows {
		if row.ID != nil && *row.ID == "8" && row.ParticipationStatus != "participating" {
			t.Fatalf("unexcluded ID 8 incorrectly matches display name 7: participation=%q status=%q reason=%v", row.ParticipationStatus, row.Status, row.ParticipationReason)
		}
	}
}
