package evidence

import (
	"context"
	"github.com/MIEnchating/sub2api-console/backend/internal/business"
	"reflect"
	"testing"
	"time"
)

func TestReviewPlanUsesStableGroupIDDespiteNumericName(t *testing.T) {
	for _, excluded := range []bool{false, true} {
		name := "selected"
		if excluded {
			name = "excluded"
		}
		t.Run(name, func(t *testing.T) {
			group7, group8 := "7", "8"
			repo := &lateTrafficRepository{targets: []business.EvidenceTarget{
				{AccountID: "41", GroupName: "codex", GroupID: &group7},
				{AccountID: "42", GroupName: "7", GroupID: &group8},
			}}
			policy := testTrafficProbePolicy()
			policy["traffic"].(map[string]any)["enabled"] = false
			policy["scope"] = map[string]any{"managed_group_mode": "selected", "managed_group_ids": []any{"7"}}
			expected := []string{"41"}
			if excluded {
				policy["scope"] = map[string]any{"excluded_group_ids": []any{"7"}}
				expected = []string{"42"}
			}
			plan, err := New(repo, nil).Plan(context.Background(), policy, nil, nil, time.Now().UTC())
			if err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(plan.ProbeAccountIDs, expected) {
				t.Fatalf("scope selected wrong automatic probes: got=%v want=%v", plan.ProbeAccountIDs, expected)
			}
		})
	}
}
