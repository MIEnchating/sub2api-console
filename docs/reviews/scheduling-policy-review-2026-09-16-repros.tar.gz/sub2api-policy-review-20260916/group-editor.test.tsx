import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { GroupsPage } from '/root/workspace/sub2api-console/frontend/src/App';
import { api, type GroupStatus, type PolicySnapshot } from '/root/workspace/sub2api-console/frontend/src/api';

let client: QueryClient | undefined;
afterEach(() => { client?.clear(); vi.restoreAllMocks(); });

it('editing a group outside selected scope preserves its inherited enabled setting', async () => {
 const group: GroupStatus = {
  id: '7', name: 'codex', account_count: 1, scheduling_open: 1,
  scheduling_closed: 0, scheduling_unknown: 0, strategy: 'balanced',
  strategy_source: 'global_default', participation_status: 'out_of_scope',
  participation_reason: '当前仅守护指定分组，该分组未加入参与分组列表', status: 'skipped', override: null,
 };
 const policy: PolicySnapshot = {
  available: true, source: 'console', mode: '完全模式', global_strategy: 'balanced',
  group_strategies: [], missing_rate_fallback: null, change_threshold: null,
  cooldown_seconds: null, auto_apply: null, excluded_group_ids: [],
  traffic_enabled: null, probe_interval_seconds: 300, probe_model: null,
  traffic_lookback_minutes: null, max_samples_per_account: null,
  advanced_policy: { scope: { managed_group_mode: 'selected', managed_group_ids: ['8'] } }, configuration_errors: [],
 };
 vi.spyOn(api, 'groups').mockResolvedValue([group]);
 vi.spyOn(api, 'policy').mockResolvedValue(policy);
 vi.spyOn(api, 'groupProbeModels').mockResolvedValue({ models: [], complete: true } as never);
 const save = vi.spyOn(api, 'updateGroupPolicy').mockResolvedValue(group);
 client = new QueryClient({ defaultOptions: { queries: { retry: false, staleTime: Infinity } } });
 for (const key of ['group', 'scheduling_strategy']) client.setQueryData(['dictionaries', key], { items: [] });
 render(<QueryClientProvider client={client}><GroupsPage /></QueryClientProvider>);
 const edit = await screen.findByRole('button', { name: '编辑分组' });
 await waitFor(() => expect(edit).toBeEnabled());
 fireEvent.click(edit);
 fireEvent.click(await screen.findByRole('radio', { name: '价格优先' }));
 fireEvent.click(screen.getByRole('button', { name: '保存策略' }));
 await waitFor(() => expect(save).toHaveBeenCalled());
 expect(save.mock.calls[0]?.[1]).toMatchObject({ strategy: 'price_first', enabled: true });
});
