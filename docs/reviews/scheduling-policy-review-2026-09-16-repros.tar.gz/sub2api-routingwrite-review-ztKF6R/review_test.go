package routingwrite_test

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"

	"github.com/MIEnchating/sub2api-console/backend/internal/business"
	"github.com/MIEnchating/sub2api-console/backend/internal/routing"
	"github.com/MIEnchating/sub2api-console/backend/internal/routingwrite"
	"github.com/MIEnchating/sub2api-console/backend/internal/runtimepolicy"
)

func TestReviewComputedTargetMustNotWriteAfterGroupExcluded(t *testing.T) {
	service, fixture := newUpstreamCapacityWriteFixture(t, writeCapacityPointer(20), 4, 4, true)
	if _, err := fixture.store.UpdatePolicy(t.Context(), map[string]any{
		"advanced_policy": map[string]any{"scaling": map[string]any{"enabled": true}},
	}, "test"); err != nil {
		t.Fatal(err)
	}
	calculated, err := routing.NewService(fixture.store).Calculate(t.Context(), routing.Scope{}, true)
	if err != nil {
		t.Fatal(err)
	}
	if len(calculated.AccountTargets) != 2 {
		t.Fatalf("unexpected initial targets: %+v", calculated)
	}
	t.Logf("initial target 41: %+v", calculated.AccountTargets["41"])
	if _, err := fixture.store.UpdatePolicy(t.Context(), map[string]any{"excluded_group_ids": []any{"7"}}, "operator"); err != nil {
		t.Fatal(err)
	}
	applied, err := service.Apply(t.Context(), calculated.AccountTargets, "scheduler")
	if err != nil {
		t.Fatal(err)
	}
	fixture.mu.Lock()
	defer fixture.mu.Unlock()
	if applied.RemoteWrite {
		t.Fatalf("stale calculated targets mutated excluded group: result=%+v remote=%v", applied, fixture.states)
	}
}

func TestReviewPendingWritesStopWhenModeChangesDuringFirstWrite(t *testing.T) {
	_, fixture := newUpstreamCapacityWriteFixture(t, writeCapacityPointer(20), 4, 4, true)
	if _, err := fixture.store.UpdatePolicy(t.Context(), map[string]any{
		"advanced_policy": map[string]any{"writeback": map[string]any{"concurrency": 1}},
	}, "test"); err != nil {
		t.Fatal(err)
	}
	var mutations atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, request *http.Request) {
		if request.Method == http.MethodPut && mutations.Add(1) == 1 {
			if _, err := fixture.store.SetMode(request.Context(), runtimepolicy.Monitoring); err != nil {
				t.Error(err)
			}
		}
		fixture.ServeHTTP(w, request)
	}))
	t.Cleanup(server.Close)
	service := routingwrite.New(routingTarget{url: server.URL}, fixture.store)
	applied, err := service.Apply(t.Context(), map[string]business.AccountRoutingTarget{
		"41": {AccountID: "41", GroupNames: []string{"capacity-group"}, Concurrency: writeCapacityPointer(5)},
		"42": {AccountID: "42", GroupNames: []string{"capacity-group"}, Concurrency: writeCapacityPointer(6)},
	}, "scheduler")
	if err != nil {
		t.Fatal(err)
	}
	if mutations.Load() > 1 {
		t.Fatalf("writes queued behind first request ran in monitoring mode: writes=%d result=%+v", mutations.Load(), applied)
	}
}

func TestReviewPartialAutomaticReleaseRetainsBaseline(t *testing.T) {
	_, fixture := newUpstreamCapacityWriteFixture(t, writeCapacityPointer(20), 4, 4, true)
	var failScheduling atomic.Bool
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, request *http.Request) {
		if failScheduling.Load() && request.Method == http.MethodPost && request.URL.Path == "/api/v1/admin/accounts/41/schedulable" {
			http.Error(w, "scheduling update failed", http.StatusServiceUnavailable)
			return
		}
		fixture.ServeHTTP(w, request)
	}))
	t.Cleanup(server.Close)
	service := routingwrite.New(routingTarget{url: server.URL}, fixture.store)
	initial, err := service.Apply(t.Context(), map[string]business.AccountRoutingTarget{
		"41": {AccountID: "41", GroupNames: []string{"capacity-group"}, Concurrency: writeCapacityPointer(6), Schedulable: writeEnabledPointer(false), DesiredHealth: "fused"},
	}, "scheduler")
	if err != nil || initial.Failed != 0 || initial.Changed != 1 {
		t.Fatalf("initial ownership failed: %+v err=%v", initial, err)
	}
	failScheduling.Store(true)
	restored, err := service.Apply(t.Context(), map[string]business.AccountRoutingTarget{
		"41": {AccountID: "41", GroupNames: []string{"capacity-group"}, ReleaseControl: true, DesiredHealth: "excluded"},
	}, "scheduler")
	if err != nil || restored.Failed != 1 {
		t.Fatalf("expected partial restoration failure: %+v err=%v", restored, err)
	}
	baselines, err := fixture.store.RoutingBaselines(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	if len(baselines) != 1 {
		t.Fatalf("failed release deleted original baseline: baselines=%+v result=%+v", baselines, restored)
	}
}

func TestReviewVerificationDisabledMustStillEnforceCooldown(t *testing.T) {
	service, fixture := newUpstreamCapacityWriteFixture(t, writeCapacityPointer(100), 4, 5, true)
	for _, state := range fixture.states {
		state["rate_multiplier"] = "0.5"
	}
	if _, err := fixture.store.SyncManagementSnapshot(t.Context(), fixture.accounts(), []map[string]any{{"id": json.Number("7"), "name": "capacity-group"}}, "test"); err != nil {
		t.Fatal(err)
	}
	if _, err := fixture.store.UpdatePolicy(t.Context(), map[string]any{
		"cooldown_seconds": 600,
		"auto_apply":       map[string]any{"priority": false, "load_factor": false},
		"advanced_policy": map[string]any{
			"scaling":   map[string]any{"enabled": true, "cooldown_seconds": 600},
			"writeback": map[string]any{"verification": false},
			"cost_wall": map[string]any{"enabled": false},
		},
	}, "test"); err != nil {
		t.Fatal(err)
	}
	calculator := routing.NewService(fixture.store)
	scope := routing.Scope{}
	first, err := calculator.Calculate(t.Context(), scope, true)
	if err != nil {
		t.Fatal(err)
	}
	if first.AccountTargets["41"].Concurrency == nil {
		t.Fatal("missing initial scaling target")
	}
	t.Logf("first target concurrency: %d", *first.AccountTargets["41"].Concurrency)
	initial, err := service.Apply(t.Context(), first.AccountTargets, "scheduler")
	if err != nil || initial.Failed != 0 || initial.Changed == 0 {
		t.Fatalf("initial write failed: %+v err=%v", initial, err)
	}
	audit, err := fixture.store.AuditEvents(t.Context(), nil, false)
	if err != nil {
		t.Fatal(err)
	}
	for _, event := range audit {
		if event.State != "succeeded" || event.RemoteConfirmed == nil || !*event.RemoteConfirmed || event.ReadbackConfirmed == nil || *event.ReadbackConfirmed {
			t.Fatalf("unexpected audit: state=%s remote=%v readback=%v", event.State, *event.RemoteConfirmed, *event.ReadbackConfirmed)
		}
		t.Log("audit: succeeded, remote_confirmed=true, readback_confirmed=false")
	}
	previous, err := fixture.store.PreviousRoutingDecisions(t.Context(), nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("last apply: %v", previous[0].LastApplyAt)
	second, err := calculator.Calculate(t.Context(), scope, true)
	if err != nil {
		t.Fatal(err)
	}
	if target := second.AccountTargets["41"]; target.Concurrency != nil {
		t.Logf("second target concurrency: %d, cooldown: %v", *target.Concurrency, target.ScalingCooldown)
	}
	applied, err := service.Apply(t.Context(), second.AccountTargets, "scheduler")
	if err != nil {
		t.Fatal(err)
	}
	fixture.mu.Lock()
	defer fixture.mu.Unlock()
	if applied.Changed > 0 {
		t.Fatalf("second round mutated within 600-second cooldown after successful unverified write: previous=%+v result=%+v remote=%v", previous, applied, fixture.states)
	}
}
