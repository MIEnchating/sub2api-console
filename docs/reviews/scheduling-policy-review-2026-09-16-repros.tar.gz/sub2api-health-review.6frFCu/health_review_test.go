package routing

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/MIEnchating/sub2api-console/backend/internal/business"
)

func TestReviewMinimumPoolKeepsSuccessfulSlowAccountInsteadOfInvalidCredentials(t *testing.T) {
	now := time.Date(2026, 9, 16, 0, 0, 0, 0, time.UTC)
	policy := routingPolicy()
	policy["breaker"] = map[string]any{"min_pool_size": 1, "latency_occurrences": 3, "latency_window": 3, "latency_degrade_only": false}
	on, rate := true, "1"
	repo := &routingRepositoryStub{policy: policy}
	for _, id := range []string{"41", "42"} {
		repo.accounts = append(repo.accounts, business.RoutingAccount{ID: id, GroupName: "codex", Schedulable: &on, Multiplier: &rate, EffectiveState: "healthy", Metadata: map[string]any{}})
	}
	repo.samples = append(repo.samples, business.RoutingSample{AccountID: "41", Source: "traffic", Result: "failed", FailureReason: "invalid api key", ObservedAt: now.Add(-time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 401}})
	for _, age := range []time.Duration{time.Minute, 2 * time.Minute, 3 * time.Minute} {
		repo.samples = append(repo.samples, business.RoutingSample{AccountID: "42", Source: "traffic", Result: "success", ObservedAt: now.Add(-age).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 200, "first_token_ms": 20000}})
	}
	service := NewService(repo)
	service.now = func() time.Time { return now }
	result, err := service.Calculate(context.Background(), Scope{}, true)
	if err != nil {
		t.Fatal(err)
	}
	bad, slow := result.AccountDecisions["41"], result.AccountDecisions["42"]
	if bad.Schedulable || !slow.Schedulable {
		t.Fatalf("invalid credentials state=%s schedulable=%v score=%g; successful slow state=%s schedulable=%v score=%g", bad.RoutingState, bad.Schedulable, bad.HealthScore, slow.RoutingState, slow.Schedulable, slow.HealthScore)
	}
}

func TestReviewContinuouslyHealthyTrafficCanRecoverDegradedAccount(t *testing.T) {
	now := time.Date(2026, 9, 16, 0, 0, 0, 0, time.UTC)
	policy := routingPolicy()
	on, rate := true, "1"
	repo := &routingRepositoryStub{policy: policy, accounts: []business.RoutingAccount{{ID: "41", GroupName: "codex", Schedulable: &on, Multiplier: &rate, EffectiveState: "degraded", Metadata: map[string]any{}}}}
	for index := range 200 {
		repo.samples = append(repo.samples, business.RoutingSample{AccountID: "41", Source: "traffic", Result: "success", ObservedAt: now.Add(-time.Duration(index) * time.Second).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 200, "request_id": fmt.Sprint(index)}})
	}
	service := NewService(repo)
	service.now = func() time.Time { return now }
	result, err := service.Calculate(context.Background(), Scope{}, true)
	if err != nil {
		t.Fatal(err)
	}
	decision := result.AccountDecisions["41"]
	if decision.RoutingState != "healthy" {
		t.Fatalf("199 seconds of uninterrupted successes cannot recover: state=%s score=%g samples=%d reason=%s", decision.RoutingState, decision.HealthScore, decision.SampleCount, decision.Reason)
	}
}

type reviewPreviousRepository struct {
	*routingRepositoryStub
	previous []business.PreviousRoutingDecision
}

func (r *reviewPreviousRepository) PreviousRoutingDecisions(context.Context, *string, *string) ([]business.PreviousRoutingDecision, error) {
	return r.previous, nil
}

func TestReviewPendingZeroRoutingScoreDoesNotBecomePositiveQuality(t *testing.T) {
	now := time.Date(2026, 9, 16, 0, 0, 0, 0, time.UTC)
	on, rate := true, "1"
	repo := &reviewPreviousRepository{
		routingRepositoryStub: &routingRepositoryStub{policy: routingPolicy(), accounts: []business.RoutingAccount{
			{ID: "41", GroupName: "codex", Schedulable: &on, Multiplier: &rate, EffectiveState: "survivor", Metadata: map[string]any{}},
			{ID: "42", GroupName: "codex", Schedulable: &on, Multiplier: &rate, EffectiveState: "healthy", Metadata: map[string]any{}},
		}},
		previous: []business.PreviousRoutingDecision{{AccountID: "41", GroupName: "codex", State: "survivor", Payload: map[string]any{"routing_health_score": 0.0, "health_score": 0.0}}},
	}
	repo.samples = []business.RoutingSample{
		{AccountID: "41", Source: "traffic", Result: "failed", ObservedAt: now.Add(-time.Second).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 502}},
		{AccountID: "41", Source: "traffic", Result: "failed", FailureReason: "invalid api key", ObservedAt: now.Add(-121 * time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 401}},
		{AccountID: "42", Source: "traffic", Result: "success", ObservedAt: now.Add(-time.Second).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 200}},
	}
	for index := range 58 {
		repo.samples = append(repo.samples, business.RoutingSample{AccountID: "41", Source: "traffic", Result: "success", ObservedAt: now.Add(-time.Duration(122+index) * time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 200}})
	}
	service := NewService(repo)
	service.now = func() time.Time { return now }
	result, err := service.Calculate(context.Background(), Scope{}, true)
	if err != nil {
		t.Fatal(err)
	}
	decision := result.AccountDecisions["41"]
	if decision.RoutingHealthScore == 0 && decision.EvidencePending && decision.Weight > 0 {
		t.Fatalf("zero effective health bypassed: state=%s pending=%v score=%g routingScore=%g weight=%g", decision.RoutingState, decision.EvidencePending, decision.HealthScore, decision.RoutingHealthScore, decision.Weight)
	}
}
