package inspection

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"

	"github.com/MIEnchating/sub2api-console/backend/internal/business"
	"github.com/MIEnchating/sub2api-console/backend/internal/configstore"
	"github.com/MIEnchating/sub2api-console/backend/internal/evidence"
	"github.com/MIEnchating/sub2api-console/backend/internal/routing"
	"github.com/MIEnchating/sub2api-console/backend/internal/runtimepolicy"
)

type reviewTarget struct{ baseURL string }

func (target reviewTarget) TargetSettings(context.Context) (configstore.TargetSettings, error) {
	return configstore.TargetSettings{BaseURL: target.baseURL, AdminKey: "isolated-test-key", TimeoutSeconds: 2}, nil
}

func TestReviewInspectionReportsTrafficCollectionFailure(t *testing.T) {
	store, err := business.Open(filepath.Join(t.TempDir(), "business.sqlite3"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = store.Close() })
	ctx := t.Context()
	if err := store.Bootstrap(ctx); err != nil {
		t.Fatal(err)
	}
	if _, err := store.SetMode(ctx, runtimepolicy.Monitoring); err != nil {
		t.Fatal(err)
	}
	if _, err := store.UpdatePolicy(ctx, map[string]any{
		"advanced_policy": map[string]any{
			"probe":    map[string]any{"enabled": false},
			"recovery": map[string]any{"enabled": false},
		},
	}, "test"); err != nil {
		t.Fatal(err)
	}
	if _, err := store.SyncManagementSnapshot(ctx,
		[]map[string]any{{"id": json.Number("41"), "name": "test-account", "groups": []any{json.Number("7")}, "schedulable": true, "status": "active"}},
		[]map[string]any{{"id": json.Number("7"), "name": "test-group"}}, "test"); err != nil {
		t.Fatal(err)
	}
	now := time.Now().UTC()
	if err := store.MarkInspectionTask(ctx, "upstream-sync", now); err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, request *http.Request) {
		http.Error(w, "test collection endpoint unavailable", http.StatusServiceUnavailable)
	}))
	t.Cleanup(server.Close)
	tasks := openRunnerTaskStore(t)
	runner := NewRunner(store, reviewTarget{baseURL: server.URL}, evidence.New(store, nil), routing.NewService(store), nil, nil, nil, tasks)
	result, err := runner.Run(ctx, RunRequest{Automatic: true, Actor: "test"})
	if err != nil {
		t.Fatal(err)
	}
	if result.TaskID == nil {
		t.Fatal("inspection did not run")
	}
	task, err := tasks.Get(ctx, *result.TaskID)
	if err != nil {
		t.Fatal(err)
	}
	evidenceResult, ok := task.Result["evidence"].(map[string]any)
	if !ok {
		t.Fatalf("missing evidence result: %+v", task.Result)
	}
	sourceErrors, ok := evidenceResult["source_errors"].([]any)
	if !ok || len(sourceErrors) == 0 {
		t.Fatalf("collection did not exercise failure: %+v", evidenceResult)
	}
	if result.Status == "succeeded" {
		t.Fatalf("all traffic collection failed but inspection succeeded: status=%s message=%s source_errors=%v", result.Status, task.Message, sourceErrors)
	}
}
