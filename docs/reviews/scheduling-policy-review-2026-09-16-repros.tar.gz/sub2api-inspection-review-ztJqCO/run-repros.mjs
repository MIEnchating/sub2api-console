import { mkdtempSync, readFileSync, writeFileSync, symlinkSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const repository = resolve(process.argv[2] ?? process.cwd());
const fixtures = resolve(dirname(fileURLToPath(import.meta.url)), '..');
if (!existsSync(join(repository, 'backend/go.mod')) || !existsSync(join(repository, 'frontend/package.json'))) {
  throw new Error('Pass the Sub2API Console repository path as the first argument.');
}
const generated = mkdtempSync(join(tmpdir(), 'sub2api-scheduling-review-run-'));
const replacements = {};
const cases = [
  ['internal/routing/review_test.go', 'sub2api-health-review.6frFCu/health_review_test.go'],
  ['internal/routingwrite/__tests__/review_test.go', 'sub2api-routingwrite-review-ztKF6R/review_test.go'],
  ['internal/business/review_test.go', 'sub2api-policy-review-20260916/group_review_test.go'],
  ['internal/evidence/review_test.go', 'sub2api-policy-review-20260916/evidence_scope_review_test.go'],
  ['internal/inspection/review_test.go', 'sub2api-inspection-review-ztJqCO/review_test.go'],
];
let failed = false;
try {
  for (const [target, source] of cases) {
    replacements[join(repository, 'backend', target)] = join(fixtures, source);
  }
  const overlay = join(generated, 'overlay.json');
  writeFileSync(overlay, JSON.stringify({ Replace: replacements }));
  const goResult = spawnSync('go', [
    'test', '-race', `-overlay=${overlay}`, './internal/routing', './internal/routingwrite/__tests__',
    './internal/business', './internal/evidence', './internal/inspection', '-run', '^TestReview', '-count=1', '-v',
  ], { cwd: join(repository, 'backend'), stdio: 'inherit' });
  failed ||= goResult.status !== 0;
  if (goResult.error) console.error(goResult.error);

  const frontend = join(repository, 'frontend');
  symlinkSync(join(frontend, 'node_modules'), join(generated, 'node_modules'), 'dir');
  const uiTest = join(generated, 'group-editor.test.tsx');
  const uiSource = readFileSync(join(fixtures, 'sub2api-policy-review-20260916/group-editor.test.tsx'), 'utf8');
  writeFileSync(uiTest, uiSource.replaceAll('/root/workspace/sub2api-console', repository));
  const config = join(generated, 'vitest.config.ts');
  writeFileSync(config, `import { defineConfig } from 'vitest/config';\nexport default defineConfig(${JSON.stringify({
    root: frontend,
    test: { environment: 'jsdom', setupFiles: [join(frontend, 'src/test/setup.ts')], include: [uiTest] },
    resolve: { alias: { '@': join(frontend, 'src') } },
  })});\n`);
  const uiResult = spawnSync('bun', ['run', 'test', '--config', config], { cwd: frontend, stdio: 'inherit' });
  failed ||= uiResult.status !== 0;
  if (uiResult.error) console.error(uiResult.error);
} finally {
  rmSync(generated, { recursive: true, force: true });
}
process.exitCode = failed ? 1 : 0;
