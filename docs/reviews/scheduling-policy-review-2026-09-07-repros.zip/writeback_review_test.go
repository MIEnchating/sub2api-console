package routingwrite

import (
	"context"
	"encoding/json"
	"path/filepath"
	"testing"
	"time"

	"github.com/MIEnchating/sub2api-console/backend/internal/business"
	"github.com/MIEnchating/sub2api-console/backend/internal/runtimepolicy"
)

type reviewPolicySwitchRepository struct{ *business.Store }

func (repo *reviewPolicySwitchRepository) AcquireMutationLease(ctx context.Context, owner string, resources []string, now time.Time, ttl time.Duration) (bool, error) {
	if _, err := repo.Store.UpdatePolicy(ctx, map[string]any{"auto_apply": map[string]any{"priority": false}}, "operator"); err != nil {
		return false, err
	}
	return repo.Store.AcquireMutationLease(ctx, owner, resources, now, ttl)
}

func TestReviewDisablingPriorityWriteWhileAcquiringLeasePreventsMutation(t *testing.T) {
	path := filepath.Join(t.TempDir(), "review.sqlite3")
	repo, err := business.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = repo.Close() })
	ctx := context.Background()
	if err = repo.Bootstrap(ctx); err != nil {
		t.Fatal(err)
	}
	if _, err = repo.SetMode(ctx, runtimepolicy.Full); err != nil {
		t.Fatal(err)
	}
	if _, err = repo.SyncManagementSnapshot(ctx, []map[string]any{{"id": json.Number("41"), "name": "policy-change", "priority": int64(10), "schedulable": true, "groups": []any{json.Number("7")}}}, []map[string]any{{"id": json.Number("7"), "name": "codex"}}, "test"); err != nil {
		t.Fatal(err)
	}
	admin := &concurrentWriteAdmin{dbPath: path, state: map[string]any{"id": json.Number("41"), "priority": int64(10), "schedulable": true}}
	service := newTestService(&reviewPolicySwitchRepository{Store: repo}, admin)
	priority := int64(20)
	result, err := service.Apply(ctx, map[string]business.AccountRoutingTarget{"41": {AccountID: "41", Priority: &priority, GroupNames: []string{"codex"}}}, "scheduler")
	if err != nil {
		t.Fatal(err)
	}
	if admin.mutates != 0 {
		t.Fatalf("priority switch disabled before lease acquisition but mutations=%d result=%+v", admin.mutates, result)
	}
}

func TestReviewExcludedAccountCanReleasePreviouslyCapturedControl(t *testing.T) {
	path := filepath.Join(t.TempDir(), "review.sqlite3")
	repo, err := business.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = repo.Close() })
	ctx := context.Background()
	if err = repo.Bootstrap(ctx); err != nil {
		t.Fatal(err)
	}
	if _, err = repo.SetMode(ctx, runtimepolicy.Full); err != nil {
		t.Fatal(err)
	}
	if _, err = repo.SyncManagementSnapshot(ctx, []map[string]any{{"id": json.Number("41"), "name": "excluded", "priority": int64(10), "schedulable": true, "groups": []any{json.Number("7")}}}, []map[string]any{{"id": json.Number("7"), "name": "codex"}}, "test"); err != nil {
		t.Fatal(err)
	}
	baseline, managed := int64(20), int64(10)
	fingerprint := routingTargetFingerprint(testRoutingTarget)
	if err = repo.CaptureRoutingBaseline(ctx, business.RoutingBaseline{AccountID: "41", Priority: &baseline, OwnershipVersion: 1, TargetFingerprint: fingerprint}); err != nil {
		t.Fatal(err)
	}
	if err = repo.UpdateRoutingManagedIntent(ctx, "41", fingerprint, business.RoutingManagedIntent{Priority: &managed}); err != nil {
		t.Fatal(err)
	}
	if _, err = repo.UpdatePolicy(ctx, map[string]any{"advanced_policy": map[string]any{"scope": map[string]any{"excluded_account_ids": []any{"41"}}}}, "operator"); err != nil {
		t.Fatal(err)
	}
	admin := &concurrentWriteAdmin{dbPath: path, state: map[string]any{"id": json.Number("41"), "priority": int64(10), "schedulable": true}}
	result, err := newTestService(repo, admin).Apply(ctx, map[string]business.AccountRoutingTarget{"41": {AccountID: "41", ReleaseControl: true, DesiredHealth: "excluded", GroupNames: []string{"codex"}}}, "scheduler")
	if err != nil {
		t.Fatal(err)
	}
	remaining, err := repo.RoutingBaselines(ctx)
	if err != nil {
		t.Fatal(err)
	}
	if len(remaining) != 0 {
		t.Fatalf("excluded account retained %d baseline(s), result=%+v", len(remaining), result)
	}
}
