export default {
 root: "/root/workspace/sub2api-console/frontend",
 esbuild: {jsx:"automatic"},
 test:{environment:"jsdom",setupFiles:["/root/workspace/sub2api-console/frontend/src/test/setup.ts"],include:["/tmp/sub2api-scheduling-review-20260907/policy_review.test.tsx"]},
 resolve:{alias:{"@":"/root/workspace/sub2api-console/frontend/src"}}
};
