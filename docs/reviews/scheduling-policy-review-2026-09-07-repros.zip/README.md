# 调度审查隔离复现

这些用例用于展示当前问题，预期失败，不是已修复回归测试。详见工作区审查报告。

使用当前工作区 `/root/workspace/sub2api-console`，将本包解压到 `/tmp/sub2api-scheduling-review-20260907`。Go overlay 与前端测试使用此路径；若移动工作区，需要更新 overlay.json、vitest.config.mjs 和 policy_review.test.tsx 的绝对路径。

Go 复现：

```bash
cd /root/workspace/sub2api-console/backend
go test -race -overlay /tmp/sub2api-scheduling-review-20260907/overlay.json ./internal/routing ./internal/routingwrite -run '^TestReview' -count=1 -v
```

前端复现：先确保临时目录的 node_modules 符号链接指向工作区 frontend/node_modules（本包不含依赖）。

```bash
ln -s /root/workspace/sub2api-console/frontend/node_modules /tmp/sub2api-scheduling-review-20260907/node_modules
cd /root/workspace/sub2api-console/frontend
bun run test --config /tmp/sub2api-scheduling-review-20260907/vitest.config.mjs
```

链接已存在时不用重复创建。

routing_review_test.go 的 9 个用例对应报告确定问题，policy_review.test.tsx 的 1 个交互用例对应旧草稿覆盖。writeback_review_test.go 的 2 个用例核实更强的产品契约，未计入确定缺陷，详见报告说明。

这些文件只用于测试隔离执行，生产代码通过 Go overlay 和 Vite 正常导入。Go 存储使用临时 SQLite，Admin 使用既有内存 fixture，前端 Fetch 被替换为受控响应；不会调用生产上游。
