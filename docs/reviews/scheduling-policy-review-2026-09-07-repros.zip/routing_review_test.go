package routing

import (
	"context"
	"math/big"
	"testing"
	"time"

	"github.com/MIEnchating/sub2api-console/backend/internal/business"
)

func TestReviewSuccessfulRecoveryProbesOverridePreFuseTraffic(t *testing.T) {
	now := time.Date(2026, 9, 7, 12, 0, 0, 0, time.UTC)
	enabled, rate := false, "1"
	repo := &routingRepositoryStub{policy: routingPolicy(), accounts: []business.RoutingAccount{{ID: "41", GroupName: "codex", Schedulable: &enabled, Multiplier: &rate, EffectiveState: "fused", Metadata: map[string]any{}}}}
	repo.samples = []business.RoutingSample{
		{AccountID: "41", Source: "active-probe", Result: "success", ObservedAt: now.Add(-time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 200}},
		{AccountID: "41", Source: "active-probe", Result: "success", ObservedAt: now.Add(-4 * time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 200}},
		{AccountID: "41", Source: "traffic", Result: "failed", FailureReason: "unauthorized", ObservedAt: now.Add(-10 * time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 401}},
	}
	service := NewService(repo)
	service.now = func() time.Time { return now }
	result, err := service.Calculate(context.Background(), Scope{}, true)
	if err != nil {
		t.Fatal(err)
	}
	decision := result.AccountDecisions["41"]
	if decision.RoutingState != "healthy" || !decision.Schedulable {
		t.Fatalf("successful recovery probes ignored: state=%s health=%g samples=%d reason=%s", decision.RoutingState, decision.HealthScore, decision.SampleCount, decision.Reason)
	}
}

func TestReviewGlobalConcurrencyBudgetSharedAcrossPrimaryGroups(t *testing.T) {
	policy := routingPolicy()
	policy["scaling"] = map[string]any{"enabled": true, "global_max_concurrency": 100, "min_per_account": 1, "max_per_account": 100, "scale_up_ratio": 0.4, "step_up": 10}
	config, err := parseEngineConfig(policy)
	if err != nil {
		t.Fatal(err)
	}
	first, second := healthyTestCandidate("41", "codex", 100), healthyTestCandidate("42", "claude", 100)
	firstCurrent, secondCurrent := int64(45), int64(45)
	first.account.Concurrency, second.account.Concurrency = &firstCurrent, &secondCurrent
	groups := map[string][]*candidate{"codex": {first}, "claude": {second}}
	assignAccountPlacements(groups, map[string]engineConfig{"codex": config, "claude": config}, map[string][]*candidate{"41": {first}, "42": {second}})
	total := int64(0)
	for _, item := range []*candidate{first, second} {
		if item.desiredConcurrency != nil {
			total += *item.desiredConcurrency
		} else {
			total += *item.account.Concurrency
		}
	}
	if total > config.scalingGlobalMax {
		t.Fatalf("target total=%d exceeds global cap=%d (initial total=90)", total, config.scalingGlobalMax)
	}
}

func TestReviewMinimumConcurrencyMustRespectRemainingGlobalBudget(t *testing.T) {
	first, second := healthyTestCandidate("41", "codex", 100), healthyTestCandidate("42", "codex", 100)
	rank, current := 1, int64(1)
	first.rank, second.rank = &rank, &rank
	first.account.Concurrency, second.account.Concurrency = &current, &current
	applyScaling([]*candidate{first, second}, engineConfig{scalingEnabled: true, scalingGlobalMax: 5, scalingMin: 3, scalingMax: 10, scalingUpRatio: .8, scalingStepUp: 1})
	total := *first.desiredConcurrency + *second.desiredConcurrency
	if total > 5 {
		t.Fatalf("clamping to minimum exceeded budget: desired total=%d cap=5", total)
	}
}

func TestReviewPriceFirstPrefersFreeAccountAtEqualHealthAndSpeed(t *testing.T) {
	free, paid := healthyTestCandidate("41", "codex", 100), healthyTestCandidate("42", "codex", 100)
	free.rate, paid.rate = big.NewRat(0, 1), big.NewRat(1, 10)
	free.strategy, paid.strategy = "price_first", "price_first"
	calculateGroupWeights([]*candidate{free, paid}, engineConfig{weightBudget: 400, priceExp: 1, speedExp: 1, performanceMinSamples: 5, speedAdvantageCap: 4, gateFloor: 40})
	if free.weight <= paid.weight {
		t.Fatalf("free account weight=%g is below paid 0.1 account weight=%g", free.weight, paid.weight)
	}
}

func TestReviewPermittedLargePriceExponentPreservesPriceOrdering(t *testing.T) {
	policy := routingPolicy()
	policy["weights"].(map[string]any)["price_exp"] = 100
	config, err := parseEngineConfig(policy)
	if err != nil {
		t.Fatal(err)
	}
	cheap, paid := healthyTestCandidate("41", "codex", 100), healthyTestCandidate("42", "codex", 100)
	cheap.rate, paid.rate = big.NewRat(1, 10000), big.NewRat(1, 100)
	cheap.strategy, paid.strategy = "price_first", "price_first"
	calculateGroupWeights([]*candidate{cheap, paid}, config)
	if cheap.weight <= paid.weight {
		t.Fatalf("price exponent overflow erased price ordering: cheap=%g paid=%g", cheap.weight, paid.weight)
	}
}

func TestReviewRestoredBindingStillChecksNewFatalEvidence(t *testing.T) {
	config, err := parseEngineConfig(routingPolicy())
	if err != nil {
		t.Fatal(err)
	}
	enabled := false
	item := &candidate{account: business.RoutingAccount{ID: "41", GroupName: "codex", Schedulable: &enabled, EffectiveState: "binding_invalid", CatalogBindingState: "active", Metadata: map[string]any{}}, rate: big.NewRat(1, 1), health: Health{HealthScore: 0, SampleCount: 1, Fatal: true, LatestEvent: EventCredentialBad}}
	applyInitialState(item, config, business.PreviousRoutingDecision{}, time.Now())
	if item.schedulable {
		t.Fatalf("restored catalog binding bypassed fresh credential failure: state=%s reason=%s", item.state, item.reason)
	}
}

func TestReviewRecoveredAccountCancelsPendingAutomaticDeletion(t *testing.T) {
	now := time.Date(2026, 9, 7, 12, 0, 0, 0, time.UTC)
	policy := routingPolicy()
	policy["scoring"].(map[string]any)["short_window"] = 2
	policy["cleanup"] = map[string]any{"enabled": true, "action": "delete", "occurrences": 3, "window": 5, "min_fused_minutes": 30, "keep_last_in_group": false, "trigger_status_codes": []any{401}}
	enabled, rate := false, "1"
	repo := &routingRepositoryStub{policy: policy, accounts: []business.RoutingAccount{{ID: "41", GroupName: "codex", Schedulable: &enabled, Multiplier: &rate, EffectiveState: "fused", Metadata: map[string]any{}}}, cleanupState: map[string]time.Time{"41": now.Add(-40 * time.Minute)}}
	for _, minutes := range []int{1, 4} {
		repo.samples = append(repo.samples, business.RoutingSample{AccountID: "41", Source: "traffic", Result: "success", ObservedAt: now.Add(-time.Duration(minutes) * time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 200}})
	}
	for _, minutes := range []int{10, 11, 12} {
		repo.samples = append(repo.samples, business.RoutingSample{AccountID: "41", Source: "traffic", Result: "failed", FailureReason: "unauthorized", ObservedAt: now.Add(-time.Duration(minutes) * time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 401}})
	}
	service := NewService(repo)
	service.now = func() time.Time { return now }
	result, err := service.Calculate(context.Background(), Scope{}, true)
	if err != nil {
		t.Fatal(err)
	}
	decision, target := result.AccountDecisions["41"], result.AccountTargets["41"]
	if decision.RoutingState != "healthy" {
		t.Fatalf("fixture should meet recovery conditions: %+v", decision)
	}
	if target.CleanupAction != nil {
		t.Fatalf("recovered account still scheduled for %s: state=%s score=%g schedulable=%v", *target.CleanupAction, decision.RoutingState, decision.HealthScore, decision.Schedulable)
	}
}

func TestReviewNeutralClientErrorsCannotTriggerCredentialOnlyDeletion(t *testing.T) {
	now := time.Date(2026, 9, 7, 12, 0, 0, 0, time.UTC)
	policy := routingPolicy()
	policy["cleanup"] = map[string]any{"enabled": true, "action": "delete", "occurrences": 3, "window": 5, "min_fused_minutes": 30, "keep_last_in_group": true, "only_auth_errors": true, "trigger_status_codes": []any{401, 403}}
	enabled, rate := true, "1"
	repo := &routingRepositoryStub{policy: policy, cleanupState: map[string]time.Time{"41": now.Add(-40 * time.Minute)}}
	for _, id := range []string{"41", "42"} {
		repo.accounts = append(repo.accounts, business.RoutingAccount{ID: id, GroupName: "codex", Schedulable: &enabled, Multiplier: &rate, EffectiveState: "healthy", Metadata: map[string]any{}})
	}
	for _, minutes := range []int{1, 2, 3} {
		repo.samples = append(repo.samples, business.RoutingSample{AccountID: "41", Source: "traffic", Result: "failed", FailureReason: "model access denied", ObservedAt: now.Add(-time.Duration(minutes) * time.Minute).Format(time.RFC3339Nano), Payload: map[string]any{"status_code": 403}})
	}
	service := NewService(repo)
	service.now = func() time.Time { return now }
	result, err := service.Calculate(context.Background(), Scope{}, true)
	if err != nil {
		t.Fatal(err)
	}
	if result.AccountDecisions["41"].SampleCount != 0 {
		t.Fatal("fixture should be neutral client errors")
	}
	target := result.AccountTargets["41"]
	if target.CleanupAction != nil {
		t.Fatalf("neutral 403 triggered credential-only %s; state=%s", *target.CleanupAction, target.DesiredHealth)
	}
}

func TestReviewIdleHealthyAccountDoesNotScaleFromConfiguredCapacityAlone(t *testing.T) {
	item := healthyTestCandidate("41", "codex", 100)
	rank, current := 1, int64(80)
	item.rank, item.account.Concurrency = &rank, &current
	applyScaling([]*candidate{item}, engineConfig{scalingEnabled: true, scalingGlobalMax: 100, scalingMin: 1, scalingMax: 100, scalingUpRatio: .8, scalingStepUp: 5})
	if item.desiredConcurrency != nil && *item.desiredConcurrency > current {
		t.Fatalf("idle account scaled from configured capacity %d to %d without utilization evidence", current, *item.desiredConcurrency)
	}
}
